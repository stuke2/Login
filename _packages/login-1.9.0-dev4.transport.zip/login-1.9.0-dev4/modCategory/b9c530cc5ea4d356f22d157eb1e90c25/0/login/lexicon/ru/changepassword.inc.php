<?php

$_lang['login.change_password'] = 'Изменить Пароль';
$_lang['login.password_changed'] = 'Пароль изменен.';
$_lang['login.password_err'] = 'Неправильный пароль.';
$_lang['login.password_err_change'] = 'Во время изменения пароля возникла ошибка. Проверьте заполнение полей.';
$_lang['login.password_invalid_old'] = 'Неправильный старый пароль.';
$_lang['login.password_new_confirm'] = 'Подтвердить новый пароль';
$_lang['login.password_new'] = 'Новый Пароль';
$_lang['login.password_no_match'] = 'Пароли не совпадают.';
$_lang['login.password_old'] = 'Старый пароль';
$_lang['login.password_too_short'] = 'Пароль слишком короткий! Пожалуйста, выберите пароль хотя бы длиной [[+length]].';
